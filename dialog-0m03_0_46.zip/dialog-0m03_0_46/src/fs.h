
int fs_writefile(char **lines, int nline, char *description);
char **fs_readfile(int *nline, char *description);
