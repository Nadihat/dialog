
extern uint32_t crc32_table[256];
