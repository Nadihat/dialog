
void emit_blorb(
	char *fname,
	uint8_t *zimage,
	uint32_t zlength,
	struct program *prg,
	int zver,
	char *coverfname,
	char *coveralt);
